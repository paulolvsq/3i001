package gestion_pont;

public enum Couleur {
	
	ROUGE, VERT;

}
