package gestion_pont;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

public class Feu {

	private Couleur couleur;
	private ReentrantLock lock;
	private Condition estVert;
	
	public Feu(Couleur couleur) {
		this.couleur = couleur;
		lock = new ReentrantLock();
		estVert = lock.newCondition();
	}
	
	public Feu() {
		this(Couleur.ROUGE);
	}
	
	public void attendreFeuVert() {
		lock.lock();
		try {
			while(couleur == Couleur.ROUGE)
				estVert.await();
		} catch (InterruptedException e) {
			
		} finally {
			lock.unlock();
		}
	}
	
	public void changerCouleur() {
		lock.lock();
		try {
			if(couleur == Couleur.ROUGE) {
				couleur = Couleur.VERT;
				estVert.signalAll();
			}
			else {
				couleur = Couleur.ROUGE;
			}
		} finally {
			lock.unlock();
		}
	}
	
}
