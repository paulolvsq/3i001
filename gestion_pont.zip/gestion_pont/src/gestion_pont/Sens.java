package gestion_pont;

public enum Sens {

	NORD_SUD, SUD_NORD;
	
}
