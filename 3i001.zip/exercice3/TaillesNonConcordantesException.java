//num: 3670631 & 3670460
public class TaillesNonConcordantesException extends Exception{
	public TaillesNonConcordantesException(String s){
		super(s);
	}
}
