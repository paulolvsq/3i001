public class TaillesNonConcordantesException extends Exception{
    public TaillesNonConcordantesException(String s){
        super(s);
    }
}
