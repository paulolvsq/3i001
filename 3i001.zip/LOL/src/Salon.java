import java.util.ArrayList;

public class Salon {
	
	private ArrayList<Client> places;
	private int taille;
	private int nbOccupees;
	
	public Salon(int taille) {
		this.taille = taille;
		nbOccupees = 0;
		places = new ArrayList<Client>();
	}
	
	public synchronized boolean arriverClient(Client c) throws InterruptedException{
		if( nbOccupees < taille) {
			nbOccupees++;
			places.add(c);
			notifyAll();
			return true;
		}
		else {
			return false;
		}
	}
	
	public synchronized void coifferClient() throws InterruptedException{
		getClient();
		notifyAll();
	}
	
	private Client getClient() {
		nbOccupees--;
		return places.remove(0);
	}
	
	public int getNbOccupees() {
		return nbOccupees;
	}
	
	public String toString() {
		return "la salle est de taille "+taille+" et est occupée par "+nbOccupees;
	}
}
