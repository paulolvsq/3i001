
public class Client implements Runnable{
	
	Salon s;
	
	public Client(Salon s) {
		this.s = s;
	}
	
	public void run() {
		try {
			s.arriverClient(this);
			System.out.println("un client est arrivé");
			synchronized(this) {
				wait();
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
