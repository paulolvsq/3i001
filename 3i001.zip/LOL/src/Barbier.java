
public class Barbier implements Runnable{
	
	Salon s;
	
	public Barbier(Salon s) {
		this.s = s;
	}
	
	public void run(){
		while(true) {
			try {
				synchronized (s) {
					while(s.getNbOccupees() == 0) {
							s.wait();
					}
				}
				s.coifferClient();
				System.out.println("un barbier rase un client");
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
