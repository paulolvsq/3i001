
public class Test {
	
	public static void main(String[] args) {
		
		Salon s = new Salon(5);
		//Client[] tab = new Client[10];
		Thread[] tab2 = new Thread[10];
		
		Barbier b = new Barbier(s);
		Thread b1 = new Thread(b);
		b1.start();
		
		//for (int i = 0; i<10;i++) {
		//	tab[i] = new Client(s);
		//}
		
		for(int i = 0; i < 10; i++) {
			tab2[i] = new Thread(new Client(s));
			tab2[i].start();
		}
		
		
		for(int i = 0; i < 10; i++) {
			try {
				tab2[i].join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			} 
		}
		
		System.out.println(s.toString());

		
		try {
			b1.interrupt();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
}
